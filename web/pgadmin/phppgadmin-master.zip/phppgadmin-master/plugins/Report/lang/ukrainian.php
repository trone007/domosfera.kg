<?php
        /**
         * Ukrainian KOI8-U language file.
         */

        // Basic
        $plugin_lang['strplugindescription'] = 'Report plugin';
        $plugin_lang['strnoreportsdb'] = 'Ви не створили базу даних зв╕т╕в. Читайте пояснення в файл╕ INSTALL.';

        // Reports
        $plugin_lang['strreport'] = 'Зв╕т';
        $plugin_lang['strreports'] = 'Зв╕ти';
        $plugin_lang['strshowallreports'] = 'Показати вс╕ зв╕ти';
        $plugin_lang['strnoreports'] = 'Зв╕т╕в нема╓.';
        $plugin_lang['strcreatereport'] = 'Створити зв╕т';
        $plugin_lang['strreportdropped'] = 'Зв╕т видалено.';
        $plugin_lang['strreportdroppedbad'] = 'Видалення зв╕та перервано.';
        $plugin_lang['strconfdropreport'] = 'Ви впевнен╕, що бажа╓тее видалити зв╕т "%s"?';
        $plugin_lang['strreportneedsname'] = 'Вам необх╕дно вказати ╕м"я зв╕ту.';
        $plugin_lang['strreportneedsdef'] = 'Вам необх╕дно вказати SQL-запит для Вашого зв╕ту.';
        $plugin_lang['strreportcreated'] = 'Зв╕т збережено.';
        $plugin_lang['strreportcreatedbad'] = 'Збереження зв╕ту перервано.';
?>
