<?php
	/**
	 * Mongolian language filen. 
	 */

	//Basic
	$plugin_lang['strplugindescription'] = 'Report plugin';

	// Reports
	$plugin_lang['strreport'] = 'ядоХд';
	$plugin_lang['strreports'] = 'ядоХдй';
	$plugin_lang['strshowallreports'] = '№ЯЫСкСди згХ ЯдоХдй';
	$plugin_lang['strnoreports'] = 'ядоХдЯз ЮХд.';
	$plugin_lang['strcreatereport'] = 'ѓЯкФСди ЯдоХд';
	$plugin_lang['strreportdropped'] = 'ядоХд еЮЩодЯжХЮ.';
	$plugin_lang['strreportdroppedbad'] = 'ѕЮЩодЯжХЮЩХ ЯдоХдС авХвзСЮЯ.';
	$plugin_lang['strconfdropreport'] = 'їй езХвХЮй, одЯ ШЯдЩдХ еЮЩодЯжЩди ЯдоХд "%s"?';
	$plugin_lang['strreportneedsname'] = 'їСЭ ЮХЯТШЯФЩЭЯ еЫСкСди ЩЭб ЯдоХдС.';
	$plugin_lang['strreportneedsdef'] = 'їСЭ ЮХЯТШЯФЩЭЯ еЫСкСди SQL-кСавЯг ФЬб їСлХЧЯ ЯдоХдС.';
	$plugin_lang['strreportcreated'] = 'ядоХд гЯШвСЮХЮ.';
	$plugin_lang['strreportcreatedbad'] = 'ѓЯШвСЮХЮЩХ ЯдоХдС авХвзСЮЯ.';
?>
